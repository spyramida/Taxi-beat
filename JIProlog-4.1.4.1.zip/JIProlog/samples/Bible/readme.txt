/*********************************************
 * Bible                                     *
 * Sample provided by JIProlog               *
 * By Ugo Chirico, Copyrighted               *
 * 17/03/2001                                *
 * http://www.ugosweb.comcom/jiprolog        *
 *********************************************/
 
 
- This sample is a classic bible database
  It shows how to write a java application using JIProlog both by JIPEngine and JIPEngine2
  
- bible.pl
  Is the prolog file implementing benchmark application
 
- JIPBible.java
  An application using asynchronous calls with listeners by JIPEngine

- JIPBibleSync.java
  An application using synchronous calls
  
