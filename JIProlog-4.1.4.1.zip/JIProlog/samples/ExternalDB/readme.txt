/*********************************************
 * JIProlog External Database Management	 *
 * Sample provided in JIProlog				 *
 * By Ugo Chirico, Copyrighted				 *
 * 11/05/2001								 *
 * www.geocities.com/jiprolog				 *
 *********************************************/
 
 
- This sample show how to use external database of clauses.
  
- database.pl
  Is the main prolog file
 
- employee.txt
  It is the external database of clauses in text format
  
- salary.pl  
  It is the external database of clauses in prolog format
